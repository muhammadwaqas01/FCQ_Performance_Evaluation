#include "QueuePolicy.h"

namespace processor {

cMessage* FIFOQueuePolicy::peekNextJob(const cQueue& queue, int availableCPU) const {
    if (queue.isEmpty()) return nullptr;
    return static_cast<cMessage*>(queue.front());
}


cMessage* FIFO_GREEDYQueuePolicy::peekNextJob(const cQueue& queue, int availableCPU) const {
    if (queue.isEmpty()) return nullptr;
    return static_cast<cMessage*>(queue.front());
}


} // namespace processor

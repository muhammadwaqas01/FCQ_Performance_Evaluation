#include "Processor.h"
#include "Buffer.h"
#include <fstream>
#include "QueuePolicy.h"
#include <tuple>
#include <vector>

namespace processor {

Define_Module(Processor);

Processor::~Processor() {
    cancelAndDelete(endServiceMsg);
    for (auto &msgPair : endServiceMsgs) {
        cancelAndDelete(msgPair.first);
    }
    delete buffer;
    EV << "Destructor: Cleaned up all endServiceMsgs, the main endServiceMsg, and the buffer object." << endl;
}

void Processor::initialize() {
    endServiceMsg = new cMessage("end-service");

    // Buffer size and policy are now encapsulated within Buffer
    int bufferSize = par("bufferSize").intValue();
    std::string policyName = par("schedulingPolicy").stdstringValue();
    QueuePolicy* policy = nullptr;

    if (policyName == "FIFO_GREEDY") {
        policy = new FIFO_GREEDYQueuePolicy();
    } else if (policyName == "FIFO") {
        policy = new FIFOQueuePolicy();
    } else {
        // If the policy is unrecognized, default to FIFO and log a warning
        policy = new FIFOQueuePolicy();
        EV_WARN << "Unrecognized scheduling policy: " << policyName
                << ". Defaulting to FIFO policy." << endl;
        policyName = "FIFO";  // Update policy name to FIFO for further use
    }
    buffer = new Buffer(bufferSize, policy);

    CPUCapacity = par("CPUCapacity").intValue();

    checkInterval = par("checkInterval").doubleValue();
    totalJobsGenerated.resize(29, 0);  // Initialize for 1 source

    msgProcessed.resize(29, 0);
    msgDropped.resize(29, 0);
    totalServiceTime.resize(29, 0.0);

    msgsInServiceCount.resize(29, 0);
    avgMsgsInService.resize(29, 0.0);

    totalWaitingTime.resize(29, 0.0);
    waitingCount.resize(29, 0);

    totalResponseTime.resize(29, 0.0);
    responseCount.resize(29, 0);

    msgsInBufferCount.resize(29, 0); // Initialize the buffer count vector
    avgMsgsInBuffer.resize(29, 0.0); // Initialize the average buffer vector
    msgDroppedDueToPreemption.resize(29, 0);
    totalPreemptions = 0;
    totalKillingCost = 0.0;
    jobWaitingTimes.resize(29);
    registerDynamicSignals();

    scheduleAt(simTime() + checkInterval, new cMessage("checkResource"));



//    this->Exp_Srv_Time = 25;
    EV << "Set Exp_Srv_Time to the correct static value: " << Exp_Srv_Time << endl;
    EV << "Initialized with scheduling policy: " << policyName << endl;

}


void Processor::handleMessage(cMessage *msg) {
    if (endServiceMsgs.count(msg) > 0) {
        // Extract the associated job
        cMessage *job = endServiceMsgs[msg];

        // Complete the service for this job
        endService(job);
        cancelAndDelete(msg);
        endServiceMsgs.erase(msg);

        EV << "Post-release: ActiveJobsCount=" << activeJobs.size() << ".\n";
        processQueue();
        printActiveJobsDetails(activeJobs);

    } else if (strcmp(msg->getName(), "checkResource") == 0) {
        handleResourceCheck();
        delete msg;
    } else {
        handleJobArrival(msg);
    }
}


void Processor::registerDynamicSignals() {
    for (int i = 0; i < 29; ++i) {
        std::string baseName = "source" + std::to_string(i);
        signalMap[baseName + "MsgDropped"] = registerSignal((baseName + "MsgDropped").c_str());
        signalMap[baseName + "MsgProcessed"] = registerSignal((baseName + "MsgProcessed").c_str());
        EV_DETAIL << "Registered dynamic signal for source" << i << "\n";

    }
}
void Processor::emitDynamicSignal(const std::string& signalName, double value, const std::string& sourceId) {
    std::string fullSignalName = sourceId + signalName;
    if (signalMap.find(fullSignalName) != signalMap.end()) {
        emit(signalMap[fullSignalName], value);
    } else {
        EV_ERROR << "Signal " << fullSignalName << " not found. Ensure it's registered correctly." << endl;
    }
}
void Processor::printActiveJobsDetails(const std::vector<cMessage*>& activeJobs) {
    if (activeJobs.empty()) {
        EV << "No active jobs.\n";
        return;
    }
    EV << "Active jobs details (Total " << activeJobs.size() << " jobs):\n";
    for (auto job : activeJobs) {
        // Calculate remaining service time
        double serviceStartTime = job->par("serviceStartTime").doubleValue();
        double totalServiceTime = job->par("serviceTime").doubleValue();
        double remainingServiceTime = (serviceStartTime + totalServiceTime) - simTime().dbl();
        if (remainingServiceTime < 0) {
            remainingServiceTime = 0; // Ensure the remaining service time is not negative
        }

        // Get the required CPU (acquired resources) for the job
        long acquiredCPU = job->par("requiredCPU").longValue();

        // Print details of each active job including acquired CPU
        EV << "  Job ID: " << job->getId()
           << ", Source: " << job->getSenderModule()->getFullName()
           << ", Service Start Time: " << serviceStartTime
           << ", Total Service Time: " << totalServiceTime
           << ", Remaining Service Time: " << remainingServiceTime
           << ", Acquired CPU (Required CPU): " << acquiredCPU << "\n";
    }
}


void Processor::handleResourceCheck() { //Resource usage of active jobs
//    cumulativePacketsInProgress += activeJobs.size();
    checkCounts++;

    // Calculate current resource usage
    long currentCPUUsage = sumOfCPUUsedByActiveJobs();

    // Accumulate the resource usage
    sumOfOccupiedCPU += currentCPUUsage;


    // Log the starting point of resource check
    EV << "Resource check at time: " << simTime() << " with " << activeJobs.size() << " active jobs.\n";
    EV << "Current CPU Usage: " << currentCPUUsage << ", Total: " << sumOfOccupiedCPU << "\n";


    // Calculate and accumulate the number of messages in service for each source
    std::vector<int> currentIntervalCount(29, 0); // Assuming two sources; adjust size as necessary

    for (auto job : activeJobs) {
        std::string sourceId = job->getSenderModule()->getFullName();
        std::string prefix = "source[";
        size_t startPos = sourceId.find(prefix);
        if (startPos != std::string::npos) {
            startPos += prefix.length(); // Move start position past "source["
            size_t endPos = sourceId.find(']', startPos);
            if (endPos != std::string::npos) {
                std::string numPart = sourceId.substr(startPos, endPos - startPos);
                try {
                    int sourceIndex = std::stoi(numPart);
                    if (sourceIndex >= 0 && sourceIndex < currentIntervalCount.size()) {
                        currentIntervalCount[sourceIndex]++;
                    }
                } catch (const std::invalid_argument& ia) {
                    EV_ERROR << "Error parsing source index from " << sourceId << ". Error: " << ia.what() << std::endl;
                }
            }
        }
    }

    // Accumulate and log detailed counts
    for (int i = 0; i < currentIntervalCount.size(); ++i) {
        msgsInServiceCount[i] += currentIntervalCount[i];  // Accumulate counts
        EV << "Total messages from source" << i << " in service until now: " << msgsInServiceCount[i] << "\n";
    }

    // Record the number of messages in the buffer from each source
    std::vector<int> bufferCounts = buffer->getBufferCountsBySource();
    for (int i = 0; i < bufferCounts.size(); ++i) {
        msgsInBufferCount[i] += bufferCounts[i];
        EV << "Total messages from source" << i << " in buffer until now: " << msgsInBufferCount[i] << "\n";
    }

    // Schedule the next check
    scheduleAt(simTime() + checkInterval, new cMessage("checkResource"));
}

void Processor::handleJobArrival(cMessage* msg) {
    // Check if the job has an initial arrival time; set it only if it doesn't exist.
    if (!msg->hasPar("firstArrivalTime")) {
        msg->addPar("firstArrivalTime").setDoubleValue(simTime().dbl());  // Store the first arrival time
    }

    // Initialize accumulatedWaitTime if it doesn't already exist
    if (!msg->hasPar("accumulatedWaitTime")) {
        msg->addPar("accumulatedWaitTime").setDoubleValue(0.0);
    }

    // Determine the source index and increment total jobs generated for that source
    std::string sourceId = msg->hasPar("origin") ? msg->par("origin").stringValue() : "unknown";
    int sourceIndex = std::stoi(sourceId.substr(6)); // Extract source index
    totalJobsGenerated[sourceIndex]++;
    EV << "INFO: Job generated from Source " << sourceIndex << ": Total Generated = " << totalJobsGenerated[sourceIndex] << "\n";

    // Attempt to insert the message into the buffer
    EV_DEBUG << "Attempting to insert message ID=" << msg->getId() << " from Source " << sourceIndex << " into buffer.\n";
    bool inserted = buffer->insertMessage(msg);
    EV_DEBUG << "Buffer insertion result for message ID=" << msg->getId() << ": " << (inserted ? "Success" : "Failed - Buffer Full") << "\n";

    if (!inserted) {
        // If message insertion fails, it means the buffer is full
        msgDropped[sourceIndex]++;
        EV << "INFO: Job dropped from Source " << sourceIndex << ": Total Dropped = " << msgDropped[sourceIndex] << "\n";
        delete msg;  // Clean up the message as it cannot be queued
    } else {
        // Successfully queued message
        EV << "Message queued successfully from Source " << sourceIndex << ": Job ID = " << msg->getId() << "\n";
        buffer->printQueueDetails();
        processQueue();  // Continue processing the queue
    }
}




void Processor::processQueue() {
    std::string policyName = par("schedulingPolicy").stdstringValue();
    std::string activePolicyName;

    // Set the actual active policy based on the initialization
    if (policyName != "FIFO" && policyName != "FIFO_GREEDY") {
        activePolicyName = "FIFO";  // Default to FIFO when an unrecognized policy is provided
    } else {
        activePolicyName = policyName;  // Use the recognized policy
    }

    // Only handle jobs for the current active policy
    while (!buffer->isEmpty() && canStartNextJob()) {
        cMessage* nextJob = buffer->popNextMessage(CPUCapacity);
        if (nextJob) {
            long requiredCPU = nextJob->par("requiredCPU").longValue();

            // Ensure the conditions are met to start the job
            if (requiredCPU <= CPUCapacity) {
                startNextJob(nextJob);
            }
        }
    }

    // Handle FIFO_GREEDY preemption logic if that is the selected policy
    if (activePolicyName == "FIFO_GREEDY" && !buffer->isEmpty() && (CPUCapacity > 0)) {
        cMessage* headJob = buffer->peekNextMessage(CPUCapacity);
        if (headJob) {
            long requiredCPU = headJob->par("requiredCPU").longValue();
            if (requiredCPU > CPUCapacity) {
                identify_FIFO_GREEDY_Preemption_Job(); // Only call if FIFO_GREEDY is set
            }
        }
    }

    // Log the actual active policy being used
    EV << "Processing queue with scheduling policy: " << activePolicyName << endl;
}



long Processor::sumOfCPUUsedBy(const std::vector<cMessage*>& jobs) {
    long totalCPUUsed = 0;
    for (const auto& job : jobs) {
        totalCPUUsed += job->par("requiredCPU").longValue();
    }
    return totalCPUUsed;
}





void Processor::identify_FIFO_GREEDY_Preemption_Job() {
    double Alpha = 1.0;
    double Beta = 0.0;
    cMessage* headJob = buffer->peekNextMessage(CPUCapacity);
    if (!headJob) {
        EV << "Buffer is empty, no job to preempt.\n";
        return;
    }

    long requiredCPU = headJob->par("requiredCPU").longValue();  // CPU needed by the head job
    long totalCPUCapacity = par("CPUCapacity").intValue();  // Total available CPU
    long initialCPUUsage = sumOfCPUUsedByActiveJobs();  // Current used CPU by active jobs
    double initialCPUPercent = (double(initialCPUUsage) / totalCPUCapacity) * 100;

    // Create a copy of activeJobs to sort them without modifying the original list
    std::vector<cMessage*> sortedActiveJobs = activeJobs;

    // Sort active jobs by ascending order of their acquired CPU resources
    std::sort(sortedActiveJobs.begin(), sortedActiveJobs.end(), [](cMessage* a, cMessage* b) {
        long resourcesA = a->par("requiredCPU").longValue();
        long resourcesB = b->par("requiredCPU").longValue();

        // First sort by resources in ascending order
        if (resourcesA != resourcesB) {
            return resourcesA < resourcesB;
        }

        // If resources are the same, sort by service start time in descending order (most recent first)
        double startTimeA = a->par("serviceStartTime").doubleValue();
        double startTimeB = b->par("serviceStartTime").doubleValue();
        return startTimeA > startTimeB; // Most recent first
    });

    std::vector<cMessage*> preemptCandidates;
    long totalFreeCPU = CPUCapacity;  // Start with the already available CPU resources
    double totalKillingCost = 0;

    // Iterate through the sorted jobs and accumulate resources from the smallest jobs first
    for (auto job : sortedActiveJobs) {
        long jobCPU = job->par("requiredCPU").longValue();

        // Add the job to the preemption candidates
        preemptCandidates.push_back(job);
        totalFreeCPU += jobCPU;  // Increase the total available CPU by preempting this job

        // Calculate the killing cost (based on how long the job has been running)
        double lastServiceStartTime = job->par("lastServiceStartTime").doubleValue();
        double serviceElapsedTime = simTime().dbl() - lastServiceStartTime;
        double individualKillingCost = jobCPU * serviceElapsedTime;
        totalKillingCost += individualKillingCost;

        EV << "  Job ID: " << job->getId() << ", CPU: " << jobCPU
           << ", Service Elapsed Time: " << serviceElapsedTime
           << ", Individual Killing Cost: " << individualKillingCost << "\n";

        // Stop once we have accumulated enough resources to start the new job
        if (totalFreeCPU >= requiredCPU) {
            EV << "Enough resources accumulated by preempting jobs. Stopping further selection.\n";
            break;
        }
    }

    EV << "For Testing: Head of Buffer Job Details:\n"
       << "  Job ID: " << headJob->getId() << "\n"
       << "  Source: " << headJob->par("origin").stringValue() << "\n"
       << "  Required Resources: " << requiredCPU << "\n"
       << "  Job Service Time: " << headJob->par("serviceTime").doubleValue() << "\n";

    if (!preemptCandidates.empty()) {
        long finalCPUUsage = initialCPUUsage - sumOfCPUUsedBy(preemptCandidates) + requiredCPU;
        double finalCPUPercent = (double(finalCPUUsage) / totalCPUCapacity) * 100;

        // Calculate idling cost using the service time of the job at the head of the buffer
        double headJobServiceTime = headJob->par("serviceTime").doubleValue();
        double idlingCost = Beta * (totalCPUCapacity - initialCPUUsage) * headJobServiceTime;

        // Log total killing cost and idling cost comparison
        EV << "Total Killing Cost: " << totalKillingCost << ", Idling Cost: " << idlingCost << "\n";

        // First, check if the killing cost is less than the idling cost
        if (totalKillingCost < idlingCost) {
            EV << "Preemption criteria met: Total Killing Cost < Idling Cost.\n";
            EV << "Initial Utilization Before Preemption: CPU = " << initialCPUPercent << "%\n";
            EV << "Expected Utilization After Preemption: CPU = " << finalCPUPercent << "%\n";

            // Proceed with preemption
            implementation_FIFO_GREEDY_Preemption(preemptCandidates, totalCPUCapacity - initialCPUUsage, headJobServiceTime);
        } else {
            EV << "Preemption skipped. Killing cost is too high.\n";
            EV << "Total Killing Cost: " << totalKillingCost << ", Idling Cost: " << idlingCost << "\n";
        }
    }
}

void Processor::implementation_FIFO_GREEDY_Preemption(const std::vector<cMessage*>& preemptJobs, long initialFreeCPU, double headJobServiceTime) {
    double Alpha = 1.0;
    double Beta = 0.0;

    // Compute the idling cost using the service time of the head job
    double Idling_Cost = Beta * initialFreeCPU * headJobServiceTime;

    EV << "Preemption Implementation Function is called.\n";
    EV << "Idling Cost: " << Idling_Cost << "\n";

    // Log individual killing costs for each preempted job and compute total killing cost
    EV << "Individual Killing Costs for Preempted Jobs:\n";
    double totalKillingCostForThisPreemption = 0;  // Local variable to accumulate killing costs for this preemption
    for (auto optimalJob : preemptJobs) {
        long jobCPU = optimalJob->par("requiredCPU").longValue();
        double lastServiceStartTime = optimalJob->par("lastServiceStartTime").doubleValue();
        double serviceElapsedTime = simTime().dbl() - lastServiceStartTime;  // Only the last period in service
        double individualKillingCost = Alpha * jobCPU * serviceElapsedTime;

        EV << "  Job ID: " << optimalJob->getId() << ", Last Service Start Time: " << lastServiceStartTime
           << ", Killing Cost: " << individualKillingCost << "\n";
        totalKillingCostForThisPreemption += individualKillingCost;  // Accumulate for this preemption
    }

    EV << "Sum of Killing Costs for Preempted Jobs: " << totalKillingCostForThisPreemption << "\n";

    // Proceed only if the total killing cost is less than the idling cost
    if (totalKillingCostForThisPreemption < Idling_Cost) {
        totalPreemptions++;  // Increment the preemption counter
        totalKillingCost += totalKillingCostForThisPreemption;  // Add this preemption's killing cost to the global total

        EV << "Preemption criteria met: Total Killing Cost < Idling Cost.\n";

        // Temporary holding queue for preempted jobs
        std::vector<cMessage*> holdingQueue;

        // Add preempted jobs to the holding queue and release resources
        for (auto optimalJob : preemptJobs) {
            EV << "Job to preempt: ID=" << optimalJob->getId() << "\n";

            long jobCPU = optimalJob->par("requiredCPU").longValue();

            // Cancel the scheduled end-service message for the preempted job
            for (auto it = endServiceMsgs.begin(); it != endServiceMsgs.end(); ++it) {
                if (it->second == optimalJob) {
                    cancelAndDelete(it->first);
                    endServiceMsgs.erase(it);
                    break;
                }
            }

            // Remove the job from the active jobs list
            auto it = std::find(activeJobs.begin(), activeJobs.end(), optimalJob);
            if (it != activeJobs.end()) {
                activeJobs.erase(it);
                EV << "Job ID=" << optimalJob->getId() << " removed from active jobs list.\n";
            }

            // Release resources
            initialFreeCPU += jobCPU;  // Update the free CPU count after releasing resources
            CPUCapacity += jobCPU;

            // Add the job to the holding queue temporarily
            holdingQueue.push_back(optimalJob);
        }

        // Sort the holding queue by job arrival time (oldest first)
        std::sort(holdingQueue.begin(), holdingQueue.end(), [](cMessage* a, cMessage* b) {
            return a->par("firstArrivalTime").doubleValue() < b->par("firstArrivalTime").doubleValue();
        });

        // Process the head job from the buffer
        cMessage* headJob = buffer->popNextMessage(CPUCapacity);
        if (headJob) {
            startNextJob(headJob);
        }

        // Try adding jobs from the holding queue back into the buffer
        EV << "Processing holding queue after resource release.\n";
        for (auto job : holdingQueue) {
            if (!buffer->isFull()) {
                bool inserted = buffer->insertMessage(job);
                if (inserted) {
                    EV << "Job ID=" << job->getId() << " moved from holding queue to buffer.\n";
                }
            } else {
                EV << "Buffer is full. Dropping job ID=" << job->getId() << " from holding queue.\n";
                std::string sourceId = job->par("origin").stringValue();
                int sourceIndex = std::stoi(sourceId.substr(6)); // Assuming the 'origin' contains something like "source[6]"
                msgDropped[sourceIndex]++;
                delete job;  // Drop the job
            }
        }

        // Log the updated buffer and active jobs
        EV << "Updated Buffer Details:\n";
        buffer->printQueueDetails();
        EV << "Updated Active Jobs Details:\n";
        printActiveJobsDetails(activeJobs);
    } else {
        EV << "Preemption criteria not met: Total Killing Cost >= Idling Cost. Doing nothing.\n";
    }
}



long Processor::sumOfCPUUsedByActiveJobs() {
    long totalCPUUsed = 0;
    for (const auto& job : activeJobs) {
        totalCPUUsed += static_cast<int>(job->par("requiredCPU").longValue());
    }
    return totalCPUUsed;
}



bool Processor::canStartNextJob() {
    // Get the next job, but first, make sure to pass the available CPU resources
    cMessage* nextJob = buffer->peekNextMessage(CPUCapacity); // Pass CPUCapacity as the available CPU
    if (!nextJob) return false;

    long requiredCPU = static_cast<long>(nextJob->par("requiredCPU").longValue());


    return requiredCPU <= CPUCapacity;
}



void Processor::logQueueDetails() {
    logDetailsCount++;
    std::map<std::string, int> messagesInService, messagesInBuffer;

    for (auto& job : activeJobs) {
        messagesInService[job->getSenderModule()->getName()]++;
    }

    for (cQueue::Iterator iter(queue); !iter.end(); ++iter) {
        cMessage* job = (cMessage*)*iter;
        messagesInBuffer[job->getSenderModule()->getName()]++;
    }
}


simtime_t Processor::startService(cMessage *msg) {
    simtime_t serviceTime = msg->par("serviceTime").doubleValue();
    EV << "Starting service of " << msg->getName() << " with service time: " << serviceTime << endl;
    return serviceTime;
}

void Processor::startNextJob(cMessage *job) {
    // Record the start of service time
    simtime_t serviceStartTime = simTime();

    // Set the last service start time
    if (job->hasPar("lastServiceStartTime")) {
        job->par("lastServiceStartTime").setDoubleValue(serviceStartTime.dbl());
    } else {
        job->addPar("lastServiceStartTime").setDoubleValue(serviceStartTime.dbl());
    }

    // If it's the first service (not re-added due to preemption), set the first service start time
    if (!job->hasPar("serviceStartTime")) {
        job->addPar("serviceStartTime").setDoubleValue(serviceStartTime.dbl());
    }

    // Calculate waiting time
    simtime_t firstArrivalTime = job->par("firstArrivalTime").doubleValue();
    simtime_t waitingTime = serviceStartTime - firstArrivalTime;

    // Deduce the source index from the job's parameters or metadata
    std::string sourceId = job->getSenderModule()->getFullName();
    int sourceIndex = std::stoi(sourceId.substr(sourceId.find("[") + 1, sourceId.find("]") - sourceId.find("[") - 1));

    // Accumulate waiting times and count for averaging later
    totalWaitingTime[sourceIndex] += waitingTime.dbl();
    waitingCount[sourceIndex]++;

    // Process job resources
    long requiredCPU = static_cast<long>(job->par("requiredCPU").longValue());


    CPUCapacity -= requiredCPU;

    // Log the resource allocation and remaining free resources
    EV << "INFO: Job ID = " << job->getId()
       << " assigned " << requiredCPU << " CPU resources."
       << " Remaining free resources: " << CPUCapacity << "\n";

    // Ensure the job is added to active jobs if not already present
    if (std::find(activeJobs.begin(), activeJobs.end(), job) == activeJobs.end()) {
        activeJobs.push_back(job);
    }

    // Assuming the source ID is stored in a parameter named "origin"
    if (!job->hasPar("origin")) {
        job->addPar("origin").setStringValue(sourceId.c_str());
    }


    // Log the correct occupied and available resources after updating capacities
    long occupiedCPU = 4096 - CPUCapacity;


    double cpuUtilization = static_cast<double>(occupiedCPU) / 4096.0;

    // Print the details of all active jobs
    EV << "After starting new job, active jobs details:\n";
    printActiveJobsDetails(activeJobs);

    // Schedule end of service
    cMessage *endServiceMsg = new cMessage("end-service", job->getId());
    endServiceMsgs[endServiceMsg] = job;
    scheduleAt(simTime() + job->par("serviceTime").doubleValue(), endServiceMsg);
}

void Processor::endService(cMessage *msg) {
    simtime_t finishTime = simTime();

    // First arrival time when the job was first generated
    simtime_t firstArrivalTime = msg->par("firstArrivalTime").doubleValue();

    // Last start of service time (before the job finishes)
    simtime_t lastServiceStartTime = msg->par("lastServiceStartTime").doubleValue();

    // Calculate service time as the difference between finish time and the last start of service
    simtime_t serviceTime = finishTime - lastServiceStartTime;

    // Calculate waiting time as the difference between the last start of service and the first arrival time
    simtime_t waitingTime = lastServiceStartTime - firstArrivalTime;

    // Calculate response time: total time from first arrival to finish
    simtime_t responseTime = finishTime - firstArrivalTime;


    // Store the waiting time along with job ID and source ID in jobWaitingTimes
    int jobId = msg->getId();  // Get the job ID
    std::string sourceId = msg->par("origin").stringValue();  // Get the source ID
    int sourceIndex = std::stoi(sourceId.substr(6));  // Extract the source index from sourceId (assumes "sourceX" format)

    // Ensure the jobWaitingTimes vector has enough space for each source
    if (jobWaitingTimes.size() <= sourceIndex) {
        jobWaitingTimes.resize(sourceIndex + 1);  // Resize the outer vector if necessary
    }

    // Store the job ID, source ID, and waiting time in the appropriate source's vector
    jobWaitingTimes[sourceIndex].emplace_back(jobId, sourceId, waitingTime.dbl());

    // Accumulate service, response, and waiting times as usual...
    totalServiceTime[sourceIndex] += serviceTime.dbl();
    totalResponseTime[sourceIndex] += responseTime.dbl();
    totalWaitingTime[sourceIndex] += waitingTime.dbl();

    msgProcessed[sourceIndex]++;
    responseCount[sourceIndex]++;
    waitingCount[sourceIndex]++;

    // Log the computed metrics
    EV << "INFO: Job ID = " << jobId << " finished.\n";
    EV << "INFO: Service Time = " << serviceTime << " seconds.\n";
    EV << "INFO: Waiting Time = " << waitingTime << " seconds.\n";
    EV << "INFO: Response Time = " << responseTime << " seconds.\n";

    // Resource release and logging
    int releasedCPU = msg->par("requiredCPU").longValue();
    CPUCapacity += releasedCPU;

    EV << "INFO: Job ID = " << jobId << " finished, releasing " << releasedCPU << " CPU resources.\n";
    EV << "INFO: Total free resources after release: " << CPUCapacity << "\n";

    // Remove job from active jobs
    activeJobs.erase(std::remove(activeJobs.begin(), activeJobs.end(), msg), activeJobs.end());

    // Send the job to the next step
    send(msg, "out");

    // Process next job in the queue
    processQueue();
}


void Processor::finish() {
    for (int i = 0; i < 29; ++i) { // Loop over the sources
        double recalculatedTotalWaitingTime = 0.0; // Reset recalculated waiting time

        // Sum the individual waiting times from the jobWaitingTimes vector
        for (size_t j = 0; j < jobWaitingTimes[i].size(); ++j) {
            double waitingTime = std::get<2>(jobWaitingTimes[i][j]);  // Get the waiting time
            recalculatedTotalWaitingTime += waitingTime;  // Accumulate
        }

        // Now, calculate the average waiting time using the recalculated total
        double averageWaitingTime = recalculatedTotalWaitingTime / msgProcessed[i];
        recordScalar(("Average Waiting Time Source " + std::to_string(i)).c_str(), averageWaitingTime);

        // Log the recalculated total waiting time, average waiting time, and total jobs processed
        EV << "Source " << i << " Total Jobs Processed: " << msgProcessed[i] << "\n";
        EV << "Source " << i << " Total Waiting Time (Recalculated): " << recalculatedTotalWaitingTime << "\n";
        EV << "Source " << i << " Average Waiting Time: " << averageWaitingTime << "\n";

        // Log the individual waiting times for traceability
        EV << "Individual Waiting Times for Source " << i << ":\n";
        for (size_t j = 0; j < jobWaitingTimes[i].size(); ++j) {
            int jobId = std::get<0>(jobWaitingTimes[i][j]);  // Get the job ID
            double waitingTime = std::get<2>(jobWaitingTimes[i][j]);  // Get the waiting time
            EV << "  Job ID: " << jobId << ", Waiting Time: " << waitingTime << " seconds\n";
        }
    }

    // Dropping probability for each source
    for (int i = 0; i < 29; ++i) {
        if (totalJobsGenerated[i] > 0) {
            double droppingProbability = static_cast<double>(msgDropped[i]) / totalJobsGenerated[i];
            recordScalar(("Dropping Probability Source " + std::to_string(i)).c_str(), droppingProbability);
            EV << "Source " << i << " Dropping Probability: " << droppingProbability << "\n";
        }
    }

    // Record average service times
    for (int i = 0; i < 29; ++i) {
        if (msgProcessed[i] > 0) {
            double averageServiceTime = totalServiceTime[i] / msgProcessed[i];

            recordScalar(("Average Service Time Source " + std::to_string(i)).c_str(), averageServiceTime);

            EV << "Source " << i << " Average Service Time: " << averageServiceTime << "\n";
        }
    }


    // Record average response times
    for (int i = 0; i < 29; ++i) {
        if (msgProcessed[i] > 0) {
            double averageResponseTime = totalResponseTime[i] / msgProcessed[i];

            recordScalar(("Average Response Time Source " + std::to_string(i)).c_str(), averageResponseTime);

            EV << "Source " << i << " Average Response Time: " << averageResponseTime << "\n";
        }
    }

    // Record resource usage stats
    if (checkCounts > 0) {
        double avgCPUUsage = sumOfOccupiedCPU / checkCounts;


        double avgCPUUtilization = avgCPUUsage / par("CPUCapacity").intValue();


        recordScalar("CPU Utilization (%)", avgCPUUtilization * 100);


        EV << "Average CPU Utilization: " << avgCPUUtilization * 100 << "%\n";

    }

    // Record and log the number of messages in service and in the buffer
    for (int i = 0; i < 29; ++i) {
        if (checkCounts > 0) {
            double avgMsgsInBuffer = static_cast<double>(msgsInBufferCount[i]) / checkCounts;

            recordScalar(("Source " + std::to_string(i) + " Average Messages In Buffer").c_str(), avgMsgsInBuffer);
        }
    }

    for (int i = 0; i < 29; ++i) {
        if (checkCounts > 0) {
            double avgMsgsInService = static_cast<double>(msgsInServiceCount[i]) / checkCounts;

            recordScalar(("Source " + std::to_string(i) + " Average Messages In Service").c_str(), avgMsgsInService);
        }
    }

    // Record processed and dropped messages
    for (int i = 0; i < 29; ++i) {
        recordScalar(("Source " + std::to_string(i) + " Messages Dropped").c_str(), msgDropped[i]);
    }

    // Record processed and dropped messages
    for (int i = 0; i < 29; ++i) {
        recordScalar(("Source " + std::to_string(i) + " Messages Processed").c_str(), msgProcessed[i]);
    }

    // Preemption stats
    double averageKillingCost = totalKillingCost / simTime().dbl();
    recordScalar("Total Preemptions", totalPreemptions);
    recordScalar("Total Killing Cost", totalKillingCost);
    recordScalar("Average Killing Cost per Simulation Time", averageKillingCost);

    EV << "Total Preemptions: " << totalPreemptions << "\n";
    EV << "Total Killing Cost: " << totalKillingCost << "\n";
    EV << "Average Killing Cost per Simulation Time: " << averageKillingCost << "\n";

    // Final buffer and active jobs state
    EV << "Final Buffer State:\n";
    buffer->printQueueDetails();
    EV << "Final Active Jobs State:\n";
    printActiveJobsDetails(activeJobs);
}


}

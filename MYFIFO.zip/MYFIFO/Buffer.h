#ifndef BUFFER_H_
#define BUFFER_H_

#include <omnetpp.h>
#include "QueuePolicy.h"

using namespace omnetpp;

namespace processor {

class Buffer {
private:
    cQueue queue;
    cQueue holdingQueue;  // Add holdingQueue here
    int bufferSize;
    QueuePolicy* queuePolicy;  // Queue policy to select jobs

public:
    Buffer(int size, QueuePolicy* policy);
    ~Buffer();

    bool insertMessage(cMessage* msg);
    cMessage* peekNextMessage(int availableCPU) const;
    cMessage* popNextMessage(int availableCPU);
    void removeMessage(cMessage* msg);
    int getQueueLength() const;
    bool isEmpty() const;
    bool insertIntoHoldingQueue(cMessage* msg);  // Function for holding queue
    cMessage* retrieveFromHoldingQueue();        // Retrieve from holding queue
    bool isFull() const;
    bool isHoldingQueueEmpty() const;
    bool isMessageInQueue(cMessage* msg) const;  // New function to check if a message is in the queue

    void printQueueDetails() const;
    std::vector<int> getBufferCountsBySource() const;
    const cQueue& getQueue() const; // Add this method to access the internal queue
};
} // namespace processor

#endif /* BUFFER_H_ */
